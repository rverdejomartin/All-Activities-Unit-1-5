//variables para ayudar
let divGeneral;
let divTiempo;
let tiempoTimeout = 120; //segundos, en minutoss = 2
let interval;
let barajeo;
let cartasSacadas = [];
let parejasEncontradas = 0;
let pareja = false;
let bloq = false;

window.onload = ()=>{
    divGeneral = document.getElementById("cartas");
    divTiempo = document.getElementById("timeout");
    jugar();
}

//funcion que va a inicializar el intervalo del cronometro
function timeoutStart(){
    timeoutActualizar();
    interval = setInterval(timeoutActualizar,1000);
}

//funcion que regula si sigue restando tiempo, o si debe parar
function timeoutActualizar(){
    if(tiempoTimeout > 0){
         //calculo de minutos segundos
        let minutos = Math.floor(tiempoTimeout/60);
        let segundos = tiempoTimeout%60;

        //formateo
        let formatMinutos = String(minutos).padStart(2, '0');
        let formatSegundos = String(segundos).padStart(2, '0');

        divTiempo.innerHTML = `${formatMinutos}:${formatSegundos}`;
        tiempoTimeout--;
    }
    else if(tiempoTimeout <=0){
        clearInterval(interval);
        interval = null;
        divTiempo.innerHTML = "Se acabó el tiempo";
        let reseteoIndex = divGeneral.querySelectorAll(".cartasDiv");
        reseteoIndex.forEach(carta => {
            carta.style.backgroundImage = "none";
        });
        reiniciarJuego();
    }

}

//funcion donde vamos a randomizar las cartas
function randomizarCartas(){
    let cartasTemporal = [
        "dialga.png", "gyarados.png", "lycan.png", "pika.png", "volcanion.png", 
        "dialga.png", "gyarados.png", "lycan.png", "pika.png", "volcanion.png"
    ];
    let final = [];

    //obligamos al bucle que siga mientras no tengsa el array relleno
    while(final.length<10){
        let aleat = Math.floor(Math.random()*cartasTemporal.length);
        final.push(cartasTemporal[aleat]);//guardamos en la posicion 1 el primer aleatorio
        cartasTemporal.splice(aleat, 1); //borra la posicion que he generado aleatoriamente
    }
    
    return final;
}

function prepararCartas(){
    let cartasPreparar = divGeneral.querySelectorAll(".cartasDiv");
    cartasPreparar.forEach((carta, indice) => {
        carta.dataset.index = indice;
        carta.style.backgroundImage = "none";
        carta.classList.remove("encontrada");
    });
}

function jugar(){
    reiniciarStats();
    barajeo = randomizarCartas(); //agregamos ya las cartas barajadas
    prepararCartas();
    timeoutStart(); //empezamos la cuenta atras del cronometro

    divGeneral.removeEventListener("click", manejarClick);
    divGeneral.addEventListener("click", manejarClick);
}

function manejarClick(){
    let divCarta = null;
    let elemento = e.target;
    let voltea = true;

    if(elemento.classList.contains("cartasDiv")){
        divCarta = elemento;
    }

    if(!divCarta){
        voltea = false;
    }

    if(voltea){
        if (bloq ||divCarta.classList.contains("encontrada")){
            voltea = false;
        } else if(cartasSacadas.length === 1 && cartasSacadas[0] === divCarta){
            voltea = false;
        }
    }

    //si voltea es true, funciona el programa
    if(voltea){
        let indiceCarta = parseInt(divCarta.dataset.index);
        let nombreImg = barajeo[indiceCarta];
        divCarta.style.backgroundImage = `url('./img-cartas/${nombreImg}')`;
        divCarta.style.backgroundSize = "cover";

        cartasSacadas.pusch(divCarta);

        if(cartasSacadas.length === 2){
            //bloqueamos que se saquen mas cartas porque vamos a comparar si son pareja
            bloq = true;
            let c1 = cartasSacadas[0];
            let c2 = cartasSacadas[1];

            //sacamos los nombres de la imagen para comparar
            let nombre1 = barajeo[parseInt(carta1.dataset.index)];
            let nombre2 = barajeo[parseInt(carta2.dataset.index)];

            //y comparamos
            if(nombre1 === nombre2){
                carta1.classList.add("encontrada");
                carta2.classList.add("encontrada");
                parejasEncontradas++;
                bloq = false; //permite hacer mas clicks y seguir jugando
                
                if(parejasEncontradas === 5){
                    clearInterval(interval);
                    interval = null;
                    divTiempo.innerHTML = "¡Ganaste!";
                } else{
                    //no son pareja se vuelve a voltear
                    //aqui he buscado ayuda
                    setTimeout(()=>{
                        carta1.style.backgroundImage = "none";
                        carta2.style.backgroundImage = "none";
                        bloq = false;
                    },1000)
                }
                cartasSacadas = [];//reiniciamos el valor del array para poder volver a comparar
            }
        }
    }
}

function reiniciarJuego(){
    if(interval == null){
        jugar();
    }
}

function reiniciarStats(){
    timeout = 120;
    cartasSacadas = [];
    parejasEncontradas = 0;
    bloq = false;
    interval = null;
    divTiempo.innerHTML = timeoutStart();
}